from flask import Flask, request, Response
from jsonrpcserver import method, dispatch
from collections import Counter
from utils.metrics import calculate_metrics
from utils.letters import letters_entropy, letters_idf, corpus_char_frequency, text_char_frequency, distract_frequences
from utils.ngrams import ngram_score
from utils.syllables import syllables_counter_from_text, syllables_from_text
from utils.words import text_frequency, corpus_frequency
from utils.morphology import get_POS_tag
from utils.syntaxtree import width_depth
from utils.utility import shannon_entropy, scale

app = Flask(__name__)


@method
def ping():
    return "pong"

def reassign_result(result, unscaled_dict ,updated_minmax, value, key, minmax_dict):
    unscaled_dict[key + "_unscaled"] = value
    result[key] = \
    scale(minmax_dict[key + "_min"], minmax_dict[key + "_max"], value)[0]
    if unscaled_dict[key + "_unscaled"] < minmax_dict[key+ "_min"]:
        updated_minmax[key + "_min"] = unscaled_dict[key + "_unscaled"]
    if unscaled_dict[key + "_unscaled"] > minmax_dict[key + "_max"]:
        updated_minmax[key + "_max"] = unscaled_dict[key + "_unscaled"]

    return result, unscaled_dict, updated_minmax


@method
def process(params_dict):

    naive_metrics = calculate_metrics(params_dict["text"])
    monogram = ngram_score('utils\\russian_monograms.txt')
    bigram = ngram_score('utils\\russian_bigrams.txt')
    trigram = ngram_score('utils\\russian_trigrams.txt')
    quadgram = ngram_score('utils\\russian_quadgrams.txt')
    parsed_morph = get_POS_tag(params_dict["text"])

    metric_key_dict = {
        "complexity" : naive_metrics["complexity_unscaled"],
        "logic" : naive_metrics["logic_unscaled"],
        "letters_entropy" : letters_entropy(params_dict["text"]),
        "letters_idf": letters_idf(params_dict["text"]),
        "monogram_score" : monogram.score(params_dict["text"]),
        "bigram_score" : bigram.score(params_dict["text"]),
        "trigram_score" : trigram.score(params_dict["text"]),
        "quadgram_score": quadgram.score(params_dict["text"]),
        "syllables_entropy": shannon_entropy(syllables_from_text(params_dict["text"])),
        "words_entropy": shannon_entropy(params_dict["text"].lower().split()),
        "pos_entropy" : shannon_entropy(list(parsed_morph[0].values())),
        "animacy_entropy": shannon_entropy(list(parsed_morph[1].values())),
        "case_entropy": shannon_entropy(list(parsed_morph[2].values())),
        "gender_entropy": shannon_entropy(list(parsed_morph[3].values())),
        "number_entropy" : shannon_entropy(list(parsed_morph[4].values())),
        "maximum_depth" : width_depth(params_dict["text"])[0],
        "maximum_width" : width_depth(params_dict["text"])[1]
    }

    result = {}
    updated_minmax = {}
    unscaled_dict = {}
    minmax_dict = params_dict["minmax"]

    for key in metric_key_dict.keys():
        result, unscaled_dict, updated_minmax = reassign_result(result, unscaled_dict, updated_minmax, metric_key_dict[key], key, minmax_dict)

    result["updated_minmax"] = updated_minmax
    result["unscaled_values"] = unscaled_dict

    return result


@app.route("/", methods=["POST"])
def index():
    req = request.get_data().decode()
    response = dispatch(req)
    return Response(str(response), response.http_status, mimetype="application/json")


if __name__ == "__main__":
    app.run()

