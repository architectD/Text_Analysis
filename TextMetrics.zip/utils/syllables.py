###SYLLABLES###
from collections import Counter
from utils.utility import shannon_entropy, get_word_syllables


def syllables_from_text(text):
    result = []
    for word in filter(str.isalpha, text.lower().split(' ')):
        result.extend(get_word_syllables(word))
    return result


def syllables_counter_from_text(text):
    result = []
    for word in filter(str.isalpha, text.lower().split(' ')):
        result.extend(get_word_syllables(word))
    return Counter(result)

