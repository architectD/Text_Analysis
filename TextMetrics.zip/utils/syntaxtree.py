#SYNTAX TREE#
# GET TEXT SYNTAX TREE MAX DEPTH AND WIDTH#

from urllib.request import urlopen
from urllib.parse import quote
import json
from conllu import parse_tree
from conllu.parser import ParseException


def width_depth(text):
    url = "http://lindat.mff.cuni.cz/services/udpipe/api/process?model=russian&tokenizer&tagger&parser&data=" + quote(text)[:3100]
    contents = urlopen(url).read()
    d = json.loads(contents)
    sentences_tree = parse_tree(d['result'])
    max_depth = max([depth_tree(sentence) for sentence in sentences_tree])
    max_width = max([width_tree(sentence) for sentence in sentences_tree])

    return max_depth, max_width


def depth_tree(root):
    if not root.token:
        raise ParseException("Can't calculate, token is None.")
    if "deprel" not in root.token or "id" not in root.token:
        raise ParseException("Can't calculate, token is missing either the id or deprel fields.")

    if not root.children:
        depth = 1
    else:
        depth = max([depth_tree(child) for child in root.children]) + 1
    return depth


def width_tree(root):
    if not root.token:
        raise ParseException("Can't calculate, token is None.")
    if "deprel" not in root.token or "id" not in root.token:
        raise ParseException("Can't calculate, token is missing either the id or deprel fields.")

    return len(root.children)
