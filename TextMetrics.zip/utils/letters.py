###LETTERS###
import math
from utils.utility import shannon_entropy


def read_dictionary(filepath):
    d = {}
    with open(filepath, encoding='utf-8') as f:
        for line in f:
            (key, val) = line.split()
            d[str(key)] = int(val)
    return d


def char_frequency(str1):
    ch_dict = {}
    for n in ''.join(filter(str.isalpha, str1.upper())):
        keys = ch_dict.keys()
        if n in keys:
            ch_dict[n] += 1
        else:
            ch_dict[n] = 1
    return ch_dict


def corpus_char_frequency(text):
    corpus_dict = {}
    dictionary = read_dictionary('utils\\russian_monograms.txt')
    for key in sorted(dictionary.keys()):
        corpus_dict.update({key: dictionary[key] / 2650000})
    return corpus_dict


def text_char_frequency(text):
    text_dict = {}
    cf = char_frequency(text)
    for key in sorted(cf.keys()):
        text_dict.update({key: cf[key] / len(text) * 100})
    return text_dict


def distract_frequences(d, d2):
    dis_dict = {}
    for (k, v), (k2, v2) in zip(d.items(), d2.items()):
        if k == k2:
            dis_dict.update({k: v - v2})
    return dis_dict


def compute_idf(word, corpus):
    return math.log10(len(corpus) / sum([1.0 for i in corpus if word in i]))


def letters_entropy(text):
    return shannon_entropy(list(text.lower()))


def letters_idf(text):
    return compute_idf('а', text.lower().split())

###OUTPUT
#letter shannon_entropy()
#letter_idf
#print(corpus_char_frequency(data1))
#print(text_char_frequency(data1))
#print(distract_frequences(corpus_char_frequency(data1), text_char_frequency(data1)))
