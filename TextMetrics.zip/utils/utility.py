import numpy as np
from russ.syllables import get_syllables
from typing import List
from sklearn.preprocessing import MinMaxScaler


# def shannon_entropy(list_elements):
#     a = np.array(list_elements)
#     _, cnt = np.unique(a, return_counts=True)
#     p = cnt / np.sum(cnt)
#     H = -np.sum(p * np.log2(p))
#     return H

def scale(minimum, maximum, value):
    scaler = MinMaxScaler()
    data = [minimum, value, maximum]
    fdata = [[el] for el in data]
    scaler.fit(fdata)
    result = scaler.transform(fdata)
    return result[1]


def get_word_syllables(word: str) -> List[str]:
    return [syllable.text for syllable in get_syllables(word)]


def shannon_entropy(list_elements):
    res = []
    for val in list_elements:
        if val is not None:
            res.append(val)

    a = np.array(res)
    _, cnt = np.unique(a, return_counts=True)
    p = cnt / np.sum(cnt)
    H = -np.sum(p * np.log2(p))
    return H