###WORDS###
from wordfreq import word_frequency


def corpus_frequency(text):
    frequences_from_corpus = {}
    for word in filter(str.isalpha, text.lower().split()):
        frequences_from_corpus.update({word: word_frequency(word, 'ru')})
    return frequences_from_corpus


def text_frequency(text):
    frequences_from_text = {}
    str_list = text.lower().split()
    unique_words = set(str_list)

    for words in unique_words:
        frequences_from_text.update({words: str_list.count(words) / len(unique_words)})
    return frequences_from_text

