### MORPHOLOGY ###
import pymorphy2

morph = pymorphy2.MorphAnalyzer()


def get_POS_tag(text):
    word_POS = {}
    word_animacy = {}
    word_case = {}
    word_gender = {}
    word_number = {}
    for word in filter(str.isalpha, text.lower().split()):
        word_POS.update({word: morph.parse(word)[0].tag.POS})
        word_animacy.update({word: morph.parse(word)[0].tag.animacy})
        word_case.update({word: morph.parse(word)[0].tag.case})
        word_gender.update({word: morph.parse(word)[0].tag.gender})
        word_number.update({word: morph.parse(word)[0].tag.number})

        # print(morph.parse(word)[0].tag.POS)
    return word_POS, word_animacy, word_case, word_gender, word_number
