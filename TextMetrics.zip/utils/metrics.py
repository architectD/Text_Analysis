import requests
import statistics
from rutermextract import TermExtractor

term_extractor = TermExtractor()
url_stopwords_ru = "https://raw.githubusercontent.com/stopwords-iso/stopwords-ru/master/stopwords-ru.txt"
api_url = "http://api.plainrussian.ru/api/1.0/ru/measure/"


def term_stat(data):
    stat_norm = []
    stat_count = []
    for term in term_extractor(data):
        stat_norm.append(len(term.normalized))
        stat_count.append(term.count)
    return sum(stat_norm) / len(stat_norm), max(stat_norm), sum(stat_count) / len(stat_count), max(stat_count)


def calculate_metrics(text):
    response = requests.post(api_url, data={"text": text})
    metrics_dict = response.json()
    median_of_indexes = statistics.median([metrics_dict['indexes']['index_SMOG'], metrics_dict['indexes']['index_ari'],
                                           metrics_dict['indexes']['index_dc']])

    stat = term_stat(text)
    div_median = median_of_indexes / 3
    # fitting scale
    if ((div_median) > 10): div_median = 10

    resp_dict = {}
    resp_dict["complexity"] = div_median
    resp_dict["complexity_unscaled"] = median_of_indexes

    resp_dict["logic"] = (1.0 - ((stat[0] - 5) / 40 + (10 - stat[3]) / 20)) * 10
    resp_dict["logic_unscaled"] = stat[3]

    return resp_dict