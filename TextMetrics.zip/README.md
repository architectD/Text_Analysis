# TextMetrics
Some text metrics experiments
